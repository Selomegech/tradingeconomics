"use client"
import { useState, useEffect } from "react"
import { getIndicatorsData, getNewsData } from "../lib/api"
import { utils, writeFile } from "xlsx"
import { format, startOfWeek, startOfMonth, endOfWeek, endOfMonth } from "date-fns"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { TrendingUp, DollarSign, Users, Percent, Sun, Moon } from "lucide-react"
import { useTheme } from "next-themes"

export default function Page() {
  const [selectedCountries, setSelectedCountries] = useState(["mexico", "sweden", "new zealand", "thailand"])
  const [selectedIndicators, setSelectedIndicators] = useState(["population", "gdp", "unemployment", "inflation"])
  const [data, setData] = useState<any>(null)
  const [news, setNews] = useState<any>(null)
  const [dateFrom, setDateFrom] = useState(() => {
    const today = new Date()
    return format(today, "yyyy-MM-dd")
  })
  const [dateTo, setDateTo] = useState(() => {
    const today = new Date()
    return format(today, "yyyy-MM-dd")
  })
  const [newsDateFrom, setNewsDateFrom] = useState(() => {
    const today = new Date()
    return format(today, "yyyy-MM-dd")
  })
  const [newsDateTo, setNewsDateTo] = useState(() => {
    const today = new Date()
    return format(today, "yyyy-MM-dd")
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const apiKey = "2c398cbb33bb45c:k1v63y0dwl7e27s"
  const allCountries = ["mexico", "sweden", "new zealand", "thailand"]
  const allIndicators = ["population", "gdp", "unemployment", "inflation", "interest rate"]
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 3
  const [selectedRange, setSelectedRange] = useState<string>("today")
  const { theme, setTheme } = useTheme()

  useEffect(() => {
    if (!apiKey) {
      setError("Api Key not found")
      return
    }
    const fetchData = async () => {
      setLoading(true)
      setError(null)
      try {
        const indicatorsData = await getIndicatorsData(selectedCountries, selectedIndicators, dateFrom, dateTo, apiKey)
        setData(indicatorsData?.slice(0, -1) || null)

        // Delay the news API call by 1 second
        setTimeout(async () => {
          const newsData = await getNewsData(selectedCountries[0], newsDateFrom, newsDateTo, apiKey)
          setNews(newsData)
        }, 1000)
      } catch (e: any) {
        setError(e.message)
      } finally {
        setLoading(false)
      }
    }
    fetchData()
  }, [dateFrom, dateTo, newsDateFrom, newsDateTo, selectedCountries, selectedIndicators])

  const handleDateRangeChange = (range: string) => {
    setSelectedRange(range)
    const today = new Date()
    let fromDate = today
    let toDate = today

    switch (range) {
      case "today":
        fromDate = today
        toDate = today
        break
      case "thisWeek":
        fromDate = startOfWeek(today, { weekStartsOn: 1 })
        toDate = endOfWeek(today, { weekStartsOn: 1 })
        break
      case "thisMonth":
        fromDate = startOfMonth(today)
        toDate = endOfMonth(today)
        break
      default:
        break
    }
    setNewsDateFrom(format(fromDate, "yyyy-MM-dd"))
    setNewsDateTo(format(toDate, "yyyy-MM-dd"))
  }

  function handleDownload() {
    if (!data) return
    const ws = utils.json_to_sheet(data)
    const wb = utils.book_new()
    utils.book_append_sheet(wb, ws, "indicators")
    writeFile(wb, "indicators.xlsx")
  }

  const handlePageChange = (newPage: number) => {
    setCurrentPage(newPage)
  }

  const startIndex = (currentPage - 1) * itemsPerPage
  const selectedNews = news ? news.slice(startIndex, startIndex + itemsPerPage) : []

  const getIconForIndicator = (indicator: string) => {
    switch (indicator.toLowerCase()) {
      case "gdp":
        return <TrendingUp className="h-4 w-4 text-muted-foreground" />
      case "population":
        return <Users className="h-4 w-4 text-muted-foreground" />
      case "unemployment":
        return <Users className="h-4 w-4 text-muted-foreground" />
      case "inflation":
        return <Percent className="h-4 w-4 text-muted-foreground" />
      default:
        return <DollarSign className="h-4 w-4 text-muted-foreground" />
    }
  }

  return (
    <div className="flex min-h-screen bg-background">
      <div className="flex-1 flex flex-col space-y-8 p-8">
        <div className="flex items-center justify-between space-y-2">
          <div>
            <h2 className="text-3xl font-bold tracking-tight text-primary">My Economic Snapshot</h2>
            <p className="text-sm text-muted-foreground">Powered by Trading Economics</p>
          </div>
          <Button variant="ghost" size="icon" onClick={() => setTheme(theme === "light" ? "dark" : "light")}>
            {theme === "light" ? <Moon className="h-6 w-6" /> : <Sun className="h-6 w-6" />}
          </Button>
        </div>
        <div className="flex flex-col space-y-8">
          <Card className="p-6">
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label htmlFor="countries" className="block text-sm font-medium text-muted-foreground mb-2">
                  Select Countries
                </label>
                <Select
                  value={selectedCountries.join(",")}
                  onValueChange={(value) => setSelectedCountries(value.split(","))}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select countries" />
                  </SelectTrigger>
                  <SelectContent>
                    {allCountries.map((country) => (
                      <SelectItem key={country} value={country}>
                        {country}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label htmlFor="indicators" className="block text-sm font-medium text-muted-foreground mb-2">
                  Select Indicators
                </label>
                <Select
                  value={selectedIndicators.join(",")}
                  onValueChange={(value) => setSelectedIndicators(value.split(","))}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue placeholder="Select indicators" />
                  </SelectTrigger>
                  <SelectContent>
                    {allIndicators.map((indicator) => (
                      <SelectItem key={indicator} value={indicator}>
                        {indicator}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label htmlFor="from" className="block text-sm font-medium text-muted-foreground mb-2">
                  Date from
                </label>
                <Input type="date" id="from" onChange={(e) => setDateFrom(e.target.value)} value={dateFrom} />
              </div>
              <div>
                <label htmlFor="to" className="block text-sm font-medium text-muted-foreground mb-2">
                  Date to
                </label>
                <Input type="date" id="to" onChange={(e) => setDateTo(e.target.value)} value={dateTo} />
              </div>
            </div>
          </Card>
          {error && <div className="text-red-500">{error}</div>}
          {loading ? (
            <div className="text-center">Loading...</div>
          ) : (
            data &&
            data.length > 0 && (
              <>
                <div className="grid grid-cols-2 gap-4">
                  {selectedIndicators.slice(0, 4).map((indicator, index) => (
                    <Card key={index}>
                      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                        <CardTitle className="text-sm font-medium">
                          {indicator.charAt(0).toUpperCase() + indicator.slice(1)}
                        </CardTitle>
                        {getIconForIndicator(indicator)}
                      </CardHeader>
                      <CardContent>
                        <div className="text-2xl font-bold text-primary">
                          {data
                            .find((item: any) => item.Category.toLowerCase() === indicator.toLowerCase())
                            ?.Value.toLocaleString()}
                        </div>
                        <p className="text-xs text-muted-foreground">
                          {data.find((item: any) => item.Category.toLowerCase() === indicator.toLowerCase())?.Country}
                        </p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
                <Card className="p-6">
                  <h3 className="text-lg font-semibold mb-4 text-secondary">Indicators Data</h3>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Country</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Value</TableHead>
                        <TableHead>Last Updated</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {data.map((item: any, index: number) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">{item.Country}</TableCell>
                          <TableCell>{item.Category}</TableCell>
                          <TableCell className="text-primary">{item.Value.toLocaleString()}</TableCell>
                          <TableCell className="text-muted-foreground">
                            {new Date(item.DateTime).toLocaleDateString()}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                  <Button onClick={handleDownload} className="mt-4">
                    Download Data
                  </Button>
                </Card>
              </>
            )
          )}
        </div>
      </div>
      <Card className="w-1/3 p-6 m-8">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold text-secondary">Latest News</h3>
          <Select value={selectedRange} onValueChange={handleDateRangeChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select date range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="thisWeek">This Week</SelectItem>
              <SelectItem value="thisMonth">This Month</SelectItem>
            </SelectContent>
          </Select>
        </div>
        {news && news.length > 0 && (
          <>
            <ul className="space-y-4">
              {selectedNews.map((newsItem: any, index: number) => (
                <li key={index} className="border-b pb-2">
                  <a
                    href={newsItem.URL}
                    target="_blank"
                    className="text-primary hover:underline"
                    rel="noopener noreferrer"
                  >
                    {newsItem.Title}
                  </a>
                  <p className="text-sm text-muted-foreground">{newsItem.Source}</p>
                </li>
              ))}
            </ul>
            <div className="flex justify-between mt-4">
              <Button onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1} variant="outline">
                Previous
              </Button>
              <Button
                onClick={() => handlePageChange(currentPage + 1)}
                disabled={startIndex + itemsPerPage >= news.length}
                variant="outline"
              >
                Next
              </Button>
            </div>
          </>
        )}
      </Card>
    </div>
  )
}

